import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const wallets = pgTable("wallets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  address: text("address").notNull(),
  privateKey: text("private_key").notNull(), // encrypted
  balance: decimal("balance", { precision: 18, scale: 9 }).default("0"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const strategies = pgTable("strategies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  walletId: varchar("wallet_id").references(() => wallets.id).notNull(),
  name: text("name").notNull(),
  tokenPair: text("token_pair").notNull(), // e.g., "SOL/USDC"
  baseToken: text("base_token").notNull(), // token mint address
  quoteToken: text("quote_token").notNull(), // quote token mint address
  lowerPrice: decimal("lower_price", { precision: 18, scale: 9 }).notNull(),
  upperPrice: decimal("upper_price", { precision: 18, scale: 9 }).notNull(),
  gridLevels: integer("grid_levels").notNull(),
  totalInvestment: decimal("total_investment", { precision: 18, scale: 9 }).notNull(),
  status: text("status").notNull().default("active"), // active, paused, stopped
  currentPrice: decimal("current_price", { precision: 18, scale: 9 }),
  totalPnL: decimal("total_pnl", { precision: 18, scale: 9 }).default("0"),
  ordersPlaced: integer("orders_placed").default(0),
  ordersFilled: integer("orders_filled").default(0),
  config: jsonb("config"), // additional strategy configuration
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const trades = pgTable("trades", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  strategyId: varchar("strategy_id").references(() => strategies.id).notNull(),
  txSignature: text("tx_signature").notNull().unique(),
  side: text("side").notNull(), // buy, sell
  amount: decimal("amount", { precision: 18, scale: 9 }).notNull(),
  price: decimal("price", { precision: 18, scale: 9 }).notNull(),
  pnl: decimal("pnl", { precision: 18, scale: 9 }).default("0"),
  status: text("status").notNull().default("pending"), // pending, confirmed, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const telegramConfig = pgTable("telegram_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  chatId: text("chat_id").notNull(),
  botToken: text("bot_token").notNull(),
  isActive: boolean("is_active").default(true),
  notifications: jsonb("notifications").default({}), // notification preferences
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertWalletSchema = createInsertSchema(wallets).pick({
  userId: true,
  address: true,
  privateKey: true,
});

export const insertStrategySchema = createInsertSchema(strategies).pick({
  userId: true,
  walletId: true,
  name: true,
  tokenPair: true,
  baseToken: true,
  quoteToken: true,
  lowerPrice: true,
  upperPrice: true,
  gridLevels: true,
  totalInvestment: true,
  config: true,
});

export const insertTradeSchema = createInsertSchema(trades).pick({
  strategyId: true,
  txSignature: true,
  side: true,
  amount: true,
  price: true,
  pnl: true,
});

export const insertTelegramConfigSchema = createInsertSchema(telegramConfig).pick({
  userId: true,
  chatId: true,
  botToken: true,
  notifications: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type Wallet = typeof wallets.$inferSelect;

export type InsertStrategy = z.infer<typeof insertStrategySchema>;
export type Strategy = typeof strategies.$inferSelect;

export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type Trade = typeof trades.$inferSelect;

export type InsertTelegramConfig = z.infer<typeof insertTelegramConfigSchema>;
export type TelegramConfig = typeof telegramConfig.$inferSelect;
