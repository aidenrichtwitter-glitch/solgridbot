import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useWallet() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get all wallets for the user
  const {
    data: wallets,
    isLoading: walletsLoading,
    error: walletsError
  } = useQuery({
    queryKey: ["/api/wallets"],
  });

  // Create a new wallet
  const createWalletMutation = useMutation({
    mutationFn: async (walletData: { address: string; privateKey: string }) => {
      const payload = {
        userId: "user-1", // Mock user ID
        ...walletData,
      };
      return await apiRequest("POST", "/api/wallets", payload);
    },
    onSuccess: () => {
      toast({
        title: "Wallet Connected",
        description: "Your wallet has been successfully connected",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wallets"] });
    },
    onError: (error: any) => {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect wallet",
        variant: "destructive",
      });
    },
  });

  // Get wallet balance
  const getWalletBalance = useMutation({
    mutationFn: async (walletId: string) => {
      const response = await apiRequest("GET", `/api/wallets/${walletId}/balance`, undefined);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallets"] });
    },
  });

  // Helper to get the active wallet
  const activeWallet = wallets?.[0];

  // Helper to check if wallet is connected
  const isConnected = !!activeWallet;

  // Helper to get wallet balance as a number
  const getBalance = () => {
    return activeWallet ? parseFloat(activeWallet.balance) : 0;
  };

  // Helper to get formatted wallet address
  const getFormattedAddress = () => {
    if (!activeWallet?.address) return "";
    const addr = activeWallet.address;
    return `${addr.slice(0, 4)}...${addr.slice(-4)}`;
  };

  // Connect wallet (mock implementation - in production would integrate with Phantom)
  const connectWallet = async () => {
    try {
      // Mock wallet connection - in production, integrate with Phantom wallet
      const mockAddress = "7xKXt9AbCdEfGhIjKlMnOpQrStUvWxYz9AbCdEfGhIj";
      const mockPrivateKey = JSON.stringify(Array.from({ length: 64 }, () => Math.floor(Math.random() * 256)));
      
      await createWalletMutation.mutateAsync({
        address: mockAddress,
        privateKey: mockPrivateKey,
      });
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    }
  };

  // Disconnect wallet (remove from storage)
  const disconnectWallet = async () => {
    // In a real app, you'd implement wallet disconnection
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  // Refresh wallet balance
  const refreshBalance = async () => {
    if (!activeWallet) return;
    try {
      await getWalletBalance.mutateAsync(activeWallet.id);
      toast({
        title: "Balance Updated",
        description: "Wallet balance has been refreshed",
      });
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "Failed to refresh wallet balance",
        variant: "destructive",
      });
    }
  };

  return {
    wallets,
    activeWallet,
    isConnected,
    walletsLoading,
    walletsError,
    getBalance,
    getFormattedAddress,
    connectWallet,
    disconnectWallet,
    refreshBalance,
    createWalletMutation,
    getWalletBalance,
  };
}
