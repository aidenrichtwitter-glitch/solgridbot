import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useStrategies() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get all strategies
  const {
    data: strategies,
    isLoading: strategiesLoading,
    error: strategiesError
  } = useQuery({
    queryKey: ["/api/strategies"],
  });

  // Get strategy by ID
  const useStrategy = (id: string) => {
    return useQuery({
      queryKey: ["/api/strategies", id],
      enabled: !!id,
    });
  };

  // Create new strategy
  const createStrategyMutation = useMutation({
    mutationFn: async (strategyData: any) => {
      return await apiRequest("POST", "/api/strategies", strategyData);
    },
    onSuccess: () => {
      toast({
        title: "Strategy Created",
        description: "Your grid strategy has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/strategies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create strategy",
        variant: "destructive",
      });
    },
  });

  // Update strategy status (pause/resume/stop)
  const updateStrategyMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      return await apiRequest("PATCH", `/api/strategies/${id}`, { status });
    },
    onSuccess: (_, variables) => {
      const action = variables.status === 'paused' ? 'paused' : 
                   variables.status === 'active' ? 'resumed' : 'stopped';
      toast({
        title: "Strategy Updated",
        description: `Strategy has been ${action} successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/strategies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update strategy",
        variant: "destructive",
      });
    },
  });

  // Delete strategy
  const deleteStrategyMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/strategies/${id}`, undefined);
    },
    onSuccess: () => {
      toast({
        title: "Strategy Deleted",
        description: "Strategy has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/strategies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Deletion Failed",
        description: error.message || "Failed to delete strategy",
        variant: "destructive",
      });
    },
  });

  // Helper functions
  const getActiveStrategies = () => {
    return strategies?.filter((strategy: any) => strategy.status === 'active') || [];
  };

  const getPausedStrategies = () => {
    return strategies?.filter((strategy: any) => strategy.status === 'paused') || [];
  };

  const getStoppedStrategies = () => {
    return strategies?.filter((strategy: any) => strategy.status === 'stopped') || [];
  };

  const getTotalPnL = () => {
    return strategies?.reduce((total: number, strategy: any) => {
      return total + parseFloat(strategy.totalPnL || "0");
    }, 0) || 0;
  };

  const getProfitableStrategiesCount = () => {
    return strategies?.filter((strategy: any) => parseFloat(strategy.totalPnL || "0") > 0).length || 0;
  };

  const getStrategyById = (id: string) => {
    return strategies?.find((strategy: any) => strategy.id === id);
  };

  // Strategy actions
  const pauseStrategy = async (id: string) => {
    await updateStrategyMutation.mutateAsync({ id, status: 'paused' });
  };

  const resumeStrategy = async (id: string) => {
    await updateStrategyMutation.mutateAsync({ id, status: 'active' });
  };

  const stopStrategy = async (id: string) => {
    await updateStrategyMutation.mutateAsync({ id, status: 'stopped' });
  };

  const deleteStrategy = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this strategy? This action cannot be undone.')) {
      await deleteStrategyMutation.mutateAsync(id);
    }
  };

  return {
    strategies,
    strategiesLoading,
    strategiesError,
    useStrategy,
    createStrategyMutation,
    updateStrategyMutation,
    deleteStrategyMutation,
    getActiveStrategies,
    getPausedStrategies,
    getStoppedStrategies,
    getTotalPnL,
    getProfitableStrategiesCount,
    getStrategyById,
    pauseStrategy,
    resumeStrategy,
    stopStrategy,
    deleteStrategy,
  };
}
