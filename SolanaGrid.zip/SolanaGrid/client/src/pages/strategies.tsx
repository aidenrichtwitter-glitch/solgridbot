import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Play, Pause, Eye, Trash2, Plus } from "lucide-react";

export default function Strategies() {
  const { data: strategies, isLoading } = useQuery({
    queryKey: ["/api/strategies"],
  });

  return (
    <div className="min-h-screen bg-dark-900">
      <Sidebar />
      
      <div className="ml-64 min-h-screen">
        <TopBar 
          title="Grid Strategies"
          subtitle="Manage your automated trading strategies"
        />

        <main className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">All Strategies</h2>
            <Button className="bg-primary-600 hover:bg-primary-700" data-testid="button-create-strategy">
              <Plus className="w-4 h-4 mr-2" />
              Create New Strategy
            </Button>
          </div>

          {isLoading ? (
            <div className="grid gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="bg-dark-800 border-gray-700">
                  <CardContent className="p-6">
                    <Skeleton className="h-20 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid gap-6">
              {strategies?.map((strategy: any) => (
                <Card key={strategy.id} className="bg-dark-800 border-gray-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-white" data-testid={`text-strategy-name-${strategy.id}`}>
                          {strategy.name}
                        </CardTitle>
                        <p className="text-sm text-gray-400">{strategy.tokenPair}</p>
                      </div>
                      <Badge 
                        variant={strategy.status === 'active' ? 'default' : 'secondary'}
                        className={strategy.status === 'active' ? 'bg-success-500/20 text-success-500' : ''}
                        data-testid={`badge-status-${strategy.id}`}
                      >
                        {strategy.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-gray-400">Current Price</p>
                        <p className="font-semibold text-white" data-testid={`text-current-price-${strategy.id}`}>
                          ${strategy.currentPrice || '0.00'}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Grid Range</p>
                        <p className="font-semibold text-white" data-testid={`text-grid-range-${strategy.id}`}>
                          ${strategy.lowerPrice}-${strategy.upperPrice}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">P&L</p>
                        <p className={`font-semibold ${parseFloat(strategy.totalPnL) >= 0 ? 'text-success-500' : 'text-danger-500'}`} data-testid={`text-pnl-${strategy.id}`}>
                          {parseFloat(strategy.totalPnL) >= 0 ? '+' : ''}${strategy.totalPnL}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">Grid Levels</p>
                        <p className="font-semibold text-white" data-testid={`text-grid-levels-${strategy.id}`}>
                          {strategy.gridLevels}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm">
                        <span className="text-gray-400">
                          Orders: <span className="text-white font-medium">{strategy.ordersFilled || 0}/{strategy.ordersPlaced || 0}</span>
                        </span>
                        <span className="text-gray-400">
                          Investment: <span className="text-white font-medium">${strategy.totalInvestment}</span>
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {strategy.status === 'active' ? (
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600"
                            data-testid={`button-pause-${strategy.id}`}
                          >
                            <Pause className="w-4 h-4 mr-1" />
                            Pause
                          </Button>
                        ) : (
                          <Button 
                            size="sm" 
                            className="bg-success-500 hover:bg-success-600 text-white"
                            data-testid={`button-resume-${strategy.id}`}
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Resume
                          </Button>
                        )}
                        <Button 
                          size="sm" 
                          className="bg-primary-600 hover:bg-primary-700 text-white"
                          data-testid={`button-view-${strategy.id}`}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="text-danger-500 border-danger-500 hover:bg-danger-500/10"
                          data-testid={`button-delete-${strategy.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
