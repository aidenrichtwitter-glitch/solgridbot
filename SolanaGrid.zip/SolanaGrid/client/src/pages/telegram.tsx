import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { MessageCircle, Settings, ExternalLink } from "lucide-react";

export default function TelegramPage() {
  const { data: telegramStatus, isLoading } = useQuery({
    queryKey: ["/api/telegram/status"],
  });

  return (
    <div className="min-h-screen bg-dark-900">
      <Sidebar />
      
      <div className="ml-64 min-h-screen">
        <TopBar 
          title="Telegram Bot"
          subtitle="Manage your trading bot notifications and commands"
        />

        <main className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Bot Status */}
            <Card className="bg-dark-800 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white flex items-center">
                    <MessageCircle className="w-5 h-5 mr-2" />
                    Bot Status
                  </CardTitle>
                  {isLoading ? (
                    <Skeleton className="h-6 w-16" />
                  ) : (
                    <Badge 
                      className={telegramStatus?.isInitialized ? 'bg-success-500/20 text-success-500' : 'bg-danger-500/20 text-danger-500'}
                      data-testid="badge-bot-status"
                    >
                      {telegramStatus?.isInitialized ? 'Online' : 'Offline'}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-3">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Bot Username</span>
                      <span className="text-white font-mono" data-testid="text-bot-username">
                        {telegramStatus?.username || '@gridbot_sol'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Active Chats</span>
                      <span className="text-white" data-testid="text-active-chats">
                        {telegramStatus?.activeChats || 0}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400">Commands Today</span>
                      <span className="text-white" data-testid="text-commands-today">
                        {telegramStatus?.commandsToday || 0}
                      </span>
                    </div>
                    
                    <div className="pt-4 border-t border-gray-700">
                      <Button className="w-full bg-primary-600 hover:bg-primary-700" data-testid="button-manage-bot">
                        <Settings className="w-4 h-4 mr-2" />
                        Manage Bot Settings
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Available Commands */}
            <Card className="bg-dark-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Available Commands</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-gray-700/30 rounded-lg">
                    <p className="font-mono text-sm text-primary-400">/status</p>
                    <p className="text-xs text-gray-400 mt-1">Get overall trading status</p>
                  </div>
                  <div className="p-3 bg-gray-700/30 rounded-lg">
                    <p className="font-mono text-sm text-primary-400">/pnl</p>
                    <p className="text-xs text-gray-400 mt-1">View profit/loss summary</p>
                  </div>
                  <div className="p-3 bg-gray-700/30 rounded-lg">
                    <p className="font-mono text-sm text-primary-400">/strategies</p>
                    <p className="text-xs text-gray-400 mt-1">List all active strategies</p>
                  </div>
                  <div className="p-3 bg-gray-700/30 rounded-lg">
                    <p className="font-mono text-sm text-primary-400">/pause &lt;id&gt;</p>
                    <p className="text-xs text-gray-400 mt-1">Pause a specific strategy</p>
                  </div>
                  <div className="p-3 bg-gray-700/30 rounded-lg">
                    <p className="font-mono text-sm text-primary-400">/resume &lt;id&gt;</p>
                    <p className="text-xs text-gray-400 mt-1">Resume a paused strategy</p>
                  </div>
                  <div className="p-3 bg-gray-700/30 rounded-lg">
                    <p className="font-mono text-sm text-primary-400">/price &lt;token&gt;</p>
                    <p className="text-xs text-gray-400 mt-1">Get current token price</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="bg-dark-800 border-gray-700 lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-white">Recent Bot Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-success-500 rounded-full"></div>
                      <div>
                        <p className="text-sm font-medium text-white">/status SOL</p>
                        <p className="text-xs text-gray-400">2 minutes ago</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500">Executed</span>
                  </div>
                  
                  <div className="flex items-center justify-between py-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-success-500 rounded-full"></div>
                      <div>
                        <p className="text-sm font-medium text-white">/pause RAY</p>
                        <p className="text-xs text-gray-400">15 minutes ago</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500">Executed</span>
                  </div>
                  
                  <div className="flex items-center justify-between py-2">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-success-500 rounded-full"></div>
                      <div>
                        <p className="text-sm font-medium text-white">/pnl</p>
                        <p className="text-xs text-gray-400">1 hour ago</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500">Executed</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
