import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import StatsOverview from "@/components/dashboard/stats-overview";
import ActiveStrategies from "@/components/dashboard/active-strategies";
import QuickSetup from "@/components/dashboard/quick-setup";
import TelegramStatus from "@/components/dashboard/telegram-status";
import RecentTrades from "@/components/dashboard/recent-trades";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: strategies, isLoading: strategiesLoading } = useQuery({
    queryKey: ["/api/strategies"],
  });

  const { data: trades, isLoading: tradesLoading } = useQuery({
    queryKey: ["/api/trades"],
  });

  return (
    <div className="min-h-screen bg-dark-900">
      <Sidebar />
      
      <div className="ml-64 min-h-screen">
        <TopBar 
          title="Trading Dashboard"
          subtitle="Monitor your grid bot strategies"
        />

        <main className="p-6">
          <StatsOverview stats={stats} isLoading={statsLoading} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <ActiveStrategies 
                strategies={strategies} 
                isLoading={strategiesLoading}
              />
            </div>

            <div className="space-y-6">
              <QuickSetup />
              <TelegramStatus />
              <RecentTrades 
                trades={trades?.slice(0, 5)} 
                isLoading={tradesLoading}
              />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
