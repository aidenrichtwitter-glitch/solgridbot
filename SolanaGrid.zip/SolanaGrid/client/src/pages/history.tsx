import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowUpRight, ArrowDownLeft } from "lucide-react";

export default function History() {
  const { data: trades, isLoading } = useQuery({
    queryKey: ["/api/trades"],
  });

  return (
    <div className="min-h-screen bg-dark-900">
      <Sidebar />
      
      <div className="ml-64 min-h-screen">
        <TopBar 
          title="Trade History"
          subtitle="Review your trading activity and performance"
        />

        <main className="p-6">
          <Card className="bg-dark-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Recent Trades</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {trades?.map((trade: any) => (
                    <div 
                      key={trade.id} 
                      className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg"
                      data-testid={`trade-item-${trade.id}`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          trade.side === 'buy' ? 'bg-success-500/20' : 'bg-danger-500/20'
                        }`}>
                          {trade.side === 'buy' ? (
                            <ArrowDownLeft className={`w-5 h-5 ${trade.side === 'buy' ? 'text-success-500' : 'text-danger-500'}`} />
                          ) : (
                            <ArrowUpRight className={`w-5 h-5 ${trade.side === 'buy' ? 'text-success-500' : 'text-danger-500'}`} />
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-white" data-testid={`text-trade-action-${trade.id}`}>
                            {trade.side.toUpperCase()}
                          </p>
                          <p className="text-sm text-gray-400">
                            {new Date(trade.createdAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <p className="font-semibold text-white" data-testid={`text-trade-amount-${trade.id}`}>
                          {trade.amount}
                        </p>
                        <p className="text-sm text-gray-400" data-testid={`text-trade-price-${trade.id}`}>
                          @ ${trade.price}
                        </p>
                      </div>
                      
                      <div className="text-right">
                        <p className={`font-semibold ${parseFloat(trade.pnl) >= 0 ? 'text-success-500' : 'text-danger-500'}`} data-testid={`text-trade-pnl-${trade.id}`}>
                          {parseFloat(trade.pnl) >= 0 ? '+' : ''}${trade.pnl}
                        </p>
                        <Badge 
                          variant={trade.status === 'confirmed' ? 'default' : 'secondary'}
                          className={trade.status === 'confirmed' ? 'bg-success-500/20 text-success-500' : ''}
                          data-testid={`badge-trade-status-${trade.id}`}
                        >
                          {trade.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  
                  {!trades?.length && (
                    <div className="text-center py-12">
                      <p className="text-gray-400">No trades found</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}
