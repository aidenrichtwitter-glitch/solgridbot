import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Search, Plus, X, Settings } from "lucide-react";

interface StrategyModalProps {
  children: React.ReactNode;
  onSuccess?: () => void;
}

export default function StrategyModal({ children, onSuccess }: StrategyModalProps) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    tokenPair: "",
    baseToken: "",
    quoteToken: "",
    lowerPrice: "",
    upperPrice: "",
    gridLevels: "20",
    totalInvestment: "",
    riskLevel: "medium",
    slippageBps: "50",
    stopLoss: "",
    takeProfit: "",
    notes: "",
  });
  const [tokenSearch, setTokenSearch] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tokens } = useQuery({
    queryKey: ["/api/tokens/search", tokenSearch],
    enabled: tokenSearch.length > 2,
  });

  const { data: wallets } = useQuery({
    queryKey: ["/api/wallets"],
  });

  const createStrategyMutation = useMutation({
    mutationFn: async (data: any) => {
      const strategyData = {
        userId: "user-1", // Mock user ID
        walletId: wallets?.[0]?.id || "wallet-1",
        ...data,
        lowerPrice: data.lowerPrice,
        upperPrice: data.upperPrice,
        gridLevels: parseInt(data.gridLevels),
        totalInvestment: data.totalInvestment,
        config: {
          riskLevel: data.riskLevel,
          slippageBps: parseInt(data.slippageBps),
          stopLoss: data.stopLoss,
          takeProfit: data.takeProfit,
          notes: data.notes,
        },
      };

      return await apiRequest("POST", "/api/strategies", strategyData);
    },
    onSuccess: () => {
      toast({
        title: "Strategy Created",
        description: "Your grid trading strategy has been created and activated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/strategies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setOpen(false);
      setStep(1);
      setFormData({
        name: "",
        tokenPair: "",
        baseToken: "",
        quoteToken: "",
        lowerPrice: "",
        upperPrice: "",
        gridLevels: "20",
        totalInvestment: "",
        riskLevel: "medium",
        slippageBps: "50",
        stopLoss: "",
        takeProfit: "",
        notes: "",
      });
      onSuccess?.();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create strategy",
        variant: "destructive",
      });
    },
  });

  const handleTokenSelect = (token: any, type: 'base' | 'quote') => {
    if (type === 'base') {
      setFormData({
        ...formData,
        baseToken: token.address,
        tokenPair: `${token.symbol}/${formData.tokenPair.split('/')[1] || 'USDC'}`,
      });
    } else {
      setFormData({
        ...formData,
        quoteToken: token.address,
        tokenPair: `${formData.tokenPair.split('/')[0] || 'SOL'}/${token.symbol}`,
      });
    }
  };

  const nextStep = () => {
    if (step === 1) {
      if (!formData.tokenPair || !formData.baseToken || !formData.quoteToken) {
        toast({
          title: "Error",
          description: "Please select both base and quote tokens",
          variant: "destructive",
        });
        return;
      }
    }
    setStep(step + 1);
  };

  const prevStep = () => setStep(step - 1);

  const handleSubmit = () => {
    if (!formData.name || !formData.lowerPrice || !formData.upperPrice || !formData.totalInvestment) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(formData.lowerPrice) >= parseFloat(formData.upperPrice)) {
      toast({
        title: "Error",
        description: "Lower price must be less than upper price",
        variant: "destructive",
      });
      return;
    }

    createStrategyMutation.mutate(formData);
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="space-y-4">
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Strategy Name</Label>
          <Input
            placeholder="e.g., SOL/USDC Grid Strategy"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
            data-testid="input-strategy-name"
          />
        </div>

        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Token Pair Selection</Label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-xs text-gray-400 mb-1 block">Base Token</Label>
              <div className="relative">
                <Input
                  placeholder="Search base token..."
                  value={tokenSearch}
                  onChange={(e) => setTokenSearch(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 pr-8"
                  data-testid="input-base-token-search"
                />
                <Search className="absolute right-2 top-2.5 w-4 h-4 text-gray-400" />
              </div>
              {tokens && tokenSearch.length > 2 && (
                <div className="mt-2 max-h-40 overflow-y-auto bg-gray-700 rounded-md border border-gray-600">
                  {tokens.slice(0, 5).map((token: any) => (
                    <button
                      key={token.address}
                      onClick={() => handleTokenSelect(token, 'base')}
                      className="w-full px-3 py-2 text-left hover:bg-gray-600 text-white text-sm"
                      data-testid={`button-select-base-token-${token.symbol}`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{token.symbol}</span>
                        <span className="text-xs text-gray-400">{token.name}</span>
                      </div>
                    </button>
                  ))}
                </div>
              )}
              {formData.baseToken && (
                <div className="mt-2">
                  <Badge className="bg-primary-600 text-white" data-testid="badge-selected-base-token">
                    {formData.tokenPair.split('/')[0]}
                  </Badge>
                </div>
              )}
            </div>

            <div>
              <Label className="text-xs text-gray-400 mb-1 block">Quote Token</Label>
              <Select value={formData.quoteToken} onValueChange={(value) => {
                const symbol = value === 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v' ? 'USDC' : 
                              value === 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB' ? 'USDT' : 'USDC';
                setFormData({
                  ...formData,
                  quoteToken: value,
                  tokenPair: `${formData.tokenPair.split('/')[0] || 'SOL'}/${symbol}`,
                });
              }}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white" data-testid="select-quote-token">
                  <SelectValue placeholder="Select quote token" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v">USDC</SelectItem>
                  <SelectItem value="Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB">USDT</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {formData.tokenPair && formData.baseToken && formData.quoteToken && (
            <div className="mt-4 p-3 bg-gray-700 rounded-lg">
              <p className="text-sm text-gray-300">
                Selected Pair: <span className="text-white font-medium">{formData.tokenPair}</span>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Lower Price ($)</Label>
          <Input
            type="number"
            placeholder="85.00"
            value={formData.lowerPrice}
            onChange={(e) => setFormData({ ...formData, lowerPrice: e.target.value })}
            className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
            data-testid="input-lower-price"
          />
        </div>
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Upper Price ($)</Label>
          <Input
            type="number"
            placeholder="110.00"
            value={formData.upperPrice}
            onChange={(e) => setFormData({ ...formData, upperPrice: e.target.value })}
            className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
            data-testid="input-upper-price"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Grid Levels</Label>
          <Select value={formData.gridLevels} onValueChange={(value) => setFormData({ ...formData, gridLevels: value })}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white" data-testid="select-grid-levels">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-700 border-gray-600">
              <SelectItem value="10">10 Levels</SelectItem>
              <SelectItem value="15">15 Levels</SelectItem>
              <SelectItem value="20">20 Levels</SelectItem>
              <SelectItem value="25">25 Levels</SelectItem>
              <SelectItem value="50">50 Levels</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Total Investment</Label>
          <Input
            type="number"
            placeholder="1000"
            value={formData.totalInvestment}
            onChange={(e) => setFormData({ ...formData, totalInvestment: e.target.value })}
            className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
            data-testid="input-total-investment"
          />
        </div>
      </div>

      {formData.lowerPrice && formData.upperPrice && formData.gridLevels && (
        <Card className="bg-gray-700/50 border-gray-600">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-gray-300">Grid Preview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Price Range:</span>
              <span className="text-white">${formData.lowerPrice} - ${formData.upperPrice}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Grid Spacing:</span>
              <span className="text-white">
                ${((parseFloat(formData.upperPrice) - parseFloat(formData.lowerPrice)) / (parseInt(formData.gridLevels) - 1)).toFixed(4)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Investment per Grid:</span>
              <span className="text-white">
                ${formData.totalInvestment ? (parseFloat(formData.totalInvestment) / parseInt(formData.gridLevels)).toFixed(2) : '0.00'}
              </span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Risk Level</Label>
          <Select value={formData.riskLevel} onValueChange={(value) => setFormData({ ...formData, riskLevel: value })}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white" data-testid="select-risk-level">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-700 border-gray-600">
              <SelectItem value="low">Low Risk (Conservative)</SelectItem>
              <SelectItem value="medium">Medium Risk (Balanced)</SelectItem>
              <SelectItem value="high">High Risk (Aggressive)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Slippage (%)</Label>
          <Select value={formData.slippageBps} onValueChange={(value) => setFormData({ ...formData, slippageBps: value })}>
            <SelectTrigger className="bg-gray-700 border-gray-600 text-white" data-testid="select-slippage">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-gray-700 border-gray-600">
              <SelectItem value="25">0.25%</SelectItem>
              <SelectItem value="50">0.5%</SelectItem>
              <SelectItem value="100">1%</SelectItem>
              <SelectItem value="200">2%</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Stop Loss ($)</Label>
          <Input
            type="number"
            placeholder="Optional"
            value={formData.stopLoss}
            onChange={(e) => setFormData({ ...formData, stopLoss: e.target.value })}
            className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
            data-testid="input-stop-loss"
          />
        </div>
        <div>
          <Label className="text-sm font-medium text-gray-300 mb-2 block">Take Profit ($)</Label>
          <Input
            type="number"
            placeholder="Optional"
            value={formData.takeProfit}
            onChange={(e) => setFormData({ ...formData, takeProfit: e.target.value })}
            className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
            data-testid="input-take-profit"
          />
        </div>
      </div>

      <div>
        <Label className="text-sm font-medium text-gray-300 mb-2 block">Notes (Optional)</Label>
        <Textarea
          placeholder="Add any additional notes about this strategy..."
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          className="bg-gray-700 border-gray-600 text-white placeholder-gray-400 min-h-[80px]"
          data-testid="textarea-notes"
        />
      </div>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="bg-dark-800 border-gray-700 max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-strategy-modal">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Configure Grid Strategy - Step {step} of 3
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Progress indicator */}
          <div className="flex items-center space-x-4">
            {[1, 2, 3].map((stepNum) => (
              <div key={stepNum} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  stepNum <= step ? 'bg-primary-600 text-white' : 'bg-gray-600 text-gray-400'
                }`}>
                  {stepNum}
                </div>
                {stepNum < 3 && <div className={`w-8 h-px ${stepNum < step ? 'bg-primary-600' : 'bg-gray-600'} mx-2`} />}
              </div>
            ))}
          </div>

          <Separator className="border-gray-600" />

          {/* Step content */}
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}

          <Separator className="border-gray-600" />

          {/* Navigation buttons */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={prevStep}
              disabled={step === 1}
              className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
              data-testid="button-previous-step"
            >
              Previous
            </Button>
            
            {step < 3 ? (
              <Button
                onClick={nextStep}
                className="bg-primary-600 hover:bg-primary-700 text-white"
                data-testid="button-next-step"
              >
                Next
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={createStrategyMutation.isPending}
                className="bg-primary-600 hover:bg-primary-700 text-white"
                data-testid="button-create-strategy"
              >
                {createStrategyMutation.isPending ? "Creating..." : "Create Strategy"}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
