import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface RecentTradesProps {
  trades?: any[];
  isLoading: boolean;
}

export default function RecentTrades({ trades, isLoading }: RecentTradesProps) {
  return (
    <Card className="bg-dark-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-white">Recent Trades</CardTitle>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {trades?.length ? (
              trades.map((trade) => (
                <div key={trade.id} className="flex items-center justify-between py-2" data-testid={`trade-item-${trade.id}`}>
                  <div className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full ${
                      trade.side === 'buy' ? 'bg-success-500' : 'bg-danger-500'
                    }`}></div>
                    <div>
                      <p className="text-sm font-medium text-white" data-testid={`text-trade-action-${trade.id}`}>
                        {trade.side.toUpperCase()}
                      </p>
                      <p className="text-xs text-gray-400" data-testid={`text-trade-time-${trade.id}`}>
                        {new Date(trade.createdAt).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-white" data-testid={`text-trade-amount-${trade.id}`}>
                      {trade.amount}
                    </p>
                    <p className="text-xs text-gray-400" data-testid={`text-trade-price-${trade.id}`}>
                      @ ${trade.price}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-6">
                <p className="text-gray-400 text-sm">No recent trades</p>
              </div>
            )}
          </div>
        )}
        
        <Button 
          className="w-full mt-4 bg-gray-700 hover:bg-gray-600 text-white text-sm"
          data-testid="button-view-all-trades"
        >
          View All Trades
        </Button>
      </CardContent>
    </Card>
  );
}
