import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart3, Grid3X3, RefreshCw, Wallet } from "lucide-react";

interface StatsOverviewProps {
  stats?: any;
  isLoading: boolean;
}

export default function StatsOverview({ stats, isLoading }: StatsOverviewProps) {
  const statCards = [
    {
      title: "Total P&L",
      value: stats?.totalPnL ? `+$${stats.totalPnL}` : "+$0.00",
      subtitle: "+12.8% this week",
      icon: BarChart3,
      color: "text-success-500",
      testId: "total-pnl"
    },
    {
      title: "Active Strategies",
      value: stats?.activeStrategies || 0,
      subtitle: `${stats?.profitableStrategies || 0} profitable`,
      icon: Grid3X3,
      color: "text-primary-600",
      testId: "active-strategies"
    },
    {
      title: "24h Volume",
      value: stats?.volume24h ? `$${stats.volume24h}` : "$0.00",
      subtitle: `${stats?.totalTrades || 0} trades`,
      icon: RefreshCw,
      color: "text-blue-500",
      testId: "volume-24h"
    },
    {
      title: "Portfolio Value",
      value: stats?.portfolioValue ? `$${stats.portfolioValue}` : "$0.00",
      subtitle: "Across 12 tokens",
      icon: Wallet,
      color: "text-purple-500",
      testId: "portfolio-value"
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((stat) => (
        <Card key={stat.title} className="bg-dark-800 border-gray-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-gray-400">{stat.title}</h3>
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </div>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-8 w-24" />
                <Skeleton className="h-4 w-20" />
              </div>
            ) : (
              <>
                <p className={`text-2xl font-bold ${stat.color}`} data-testid={`text-${stat.testId}`}>
                  {stat.value}
                </p>
                <p className="text-sm text-gray-400 mt-2">{stat.subtitle}</p>
              </>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
