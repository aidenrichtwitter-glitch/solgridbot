import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Play, Pause, Eye, Plus } from "lucide-react";

interface ActiveStrategiesProps {
  strategies?: any[];
  isLoading: boolean;
}

export default function ActiveStrategies({ strategies, isLoading }: ActiveStrategiesProps) {
  return (
    <Card className="bg-dark-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">Active Grid Strategies</CardTitle>
          <Button 
            size="sm" 
            className="bg-primary-600 hover:bg-primary-700 text-white"
            data-testid="button-create-new-strategy"
          >
            <Plus className="w-4 h-4 mr-1" />
            Create New
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="divide-y divide-gray-700">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="p-6">
                <Skeleton className="h-20 w-full" />
              </div>
            ))
          ) : strategies?.length ? (
            strategies.map((strategy) => (
              <div key={strategy.id} className="p-6" data-testid={`strategy-card-${strategy.id}`}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    {/* Token icon placeholder */}
                    <div className="w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-bold">
                        {strategy.tokenPair.split('/')[0].slice(0, 2)}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-white" data-testid={`text-token-pair-${strategy.id}`}>
                        {strategy.tokenPair}
                      </h4>
                      <p className="text-sm text-gray-400">Grid Strategy</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant={strategy.status === 'active' ? 'default' : 'secondary'}
                      className={strategy.status === 'active' ? 'bg-success-500/20 text-success-500' : 'bg-orange-500/20 text-orange-500'}
                      data-testid={`badge-strategy-status-${strategy.id}`}
                    >
                      {strategy.status}
                    </Badge>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-gray-400">Current Price</p>
                    <p className="font-semibold text-white" data-testid={`text-current-price-${strategy.id}`}>
                      ${strategy.currentPrice || '0.00'}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Grid Range</p>
                    <p className="font-semibold text-white" data-testid={`text-grid-range-${strategy.id}`}>
                      ${strategy.lowerPrice}-${strategy.upperPrice}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">P&L</p>
                    <p 
                      className={`font-semibold ${parseFloat(strategy.totalPnL) >= 0 ? 'text-success-500' : 'text-danger-500'}`}
                      data-testid={`text-strategy-pnl-${strategy.id}`}
                    >
                      {parseFloat(strategy.totalPnL) >= 0 ? '+' : ''}${strategy.totalPnL}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Grid Levels</p>
                    <p className="font-semibold text-white" data-testid={`text-grid-levels-${strategy.id}`}>
                      {strategy.gridLevels}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="text-gray-400">
                      Orders: <span className="text-white font-medium">{strategy.ordersFilled || 0}/{strategy.ordersPlaced || 0}</span>
                    </span>
                    <span className="text-gray-400">
                      Filled: <span className="text-white font-medium">{strategy.ordersFilled || 0}</span>
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {strategy.status === 'active' ? (
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600"
                        data-testid={`button-pause-strategy-${strategy.id}`}
                      >
                        <Pause className="w-4 h-4 mr-1" />
                        Pause
                      </Button>
                    ) : (
                      <Button 
                        size="sm" 
                        className="bg-success-500 hover:bg-success-600 text-white"
                        data-testid={`button-resume-strategy-${strategy.id}`}
                      >
                        <Play className="w-4 h-4 mr-1" />
                        Resume
                      </Button>
                    )}
                    <Button 
                      size="sm" 
                      className="bg-primary-600 hover:bg-primary-700 text-white"
                      data-testid={`button-view-strategy-${strategy.id}`}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="p-6 text-center">
              <p className="text-gray-400">No active strategies found</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
