import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function QuickSetup() {
  const [formData, setFormData] = useState({
    tokenPair: "",
    lowerPrice: "",
    upperPrice: "",
    gridLevels: "20",
    amount: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createStrategyMutation = useMutation({
    mutationFn: async (data: any) => {
      // Mock strategy creation - in production, this would use real token addresses
      const strategyData = {
        userId: "user-1", // Mock user ID
        walletId: "wallet-1", // Mock wallet ID  
        name: `${data.tokenPair} Grid Strategy`,
        tokenPair: data.tokenPair,
        baseToken: "So11111111111111111111111111111111111111112", // SOL mint
        quoteToken: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", // USDC mint
        lowerPrice: data.lowerPrice,
        upperPrice: data.upperPrice,
        gridLevels: parseInt(data.gridLevels),
        totalInvestment: data.amount,
        config: {},
      };

      return await apiRequest("POST", "/api/strategies", strategyData);
    },
    onSuccess: () => {
      toast({
        title: "Strategy Created",
        description: "Your grid strategy has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/strategies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setFormData({
        tokenPair: "",
        lowerPrice: "",
        upperPrice: "",
        gridLevels: "20",
        amount: "",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create strategy",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.tokenPair || !formData.lowerPrice || !formData.upperPrice || !formData.amount) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    createStrategyMutation.mutate(formData);
  };

  return (
    <Card className="bg-dark-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-white">Quick Setup</CardTitle>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-sm font-medium text-gray-300 mb-2 block">Token Pair</Label>
            <div className="relative">
              <Input
                type="text"
                placeholder="SOL/USDC"
                value={formData.tokenPair}
                onChange={(e) => setFormData({ ...formData, tokenPair: e.target.value })}
                className="w-full px-3 py-2 pr-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                data-testid="input-token-pair"
              />
              <Search className="absolute right-3 top-2.5 w-4 h-4 text-gray-400" />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-sm font-medium text-gray-300 mb-2 block">Lower Price</Label>
              <Input
                type="number"
                placeholder="85.00"
                value={formData.lowerPrice}
                onChange={(e) => setFormData({ ...formData, lowerPrice: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                data-testid="input-lower-price"
              />
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-300 mb-2 block">Upper Price</Label>
              <Input
                type="number"
                placeholder="110.00"
                value={formData.upperPrice}
                onChange={(e) => setFormData({ ...formData, upperPrice: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                data-testid="input-upper-price"
              />
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-gray-300 mb-2 block">Grid Levels</Label>
            <Select value={formData.gridLevels} onValueChange={(value) => setFormData({ ...formData, gridLevels: value })}>
              <SelectTrigger className="w-full bg-gray-700 border-gray-600 text-white" data-testid="select-grid-levels">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-700 border-gray-600">
                <SelectItem value="10">10 Levels</SelectItem>
                <SelectItem value="20">20 Levels</SelectItem>
                <SelectItem value="50">50 Levels</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-gray-300 mb-2 block">Investment Amount</Label>
            <div className="relative">
              <Input
                type="number"
                placeholder="1000"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="w-full px-3 py-2 pr-12 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                data-testid="input-investment-amount"
              />
              <span className="absolute right-3 top-2.5 text-gray-400 text-sm">USDC</span>
            </div>
          </div>
          
          <Button 
            type="submit"
            className="w-full bg-primary-600 hover:bg-primary-700 text-white"
            disabled={createStrategyMutation.isPending}
            data-testid="button-create-grid-strategy"
          >
            {createStrategyMutation.isPending ? "Creating..." : "Create Grid Strategy"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
