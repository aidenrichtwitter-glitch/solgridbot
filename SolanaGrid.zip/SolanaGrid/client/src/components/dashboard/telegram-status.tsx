import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { MessageCircle } from "lucide-react";

export default function TelegramStatus() {
  const { data: telegramStatus, isLoading } = useQuery({
    queryKey: ["/api/telegram/status"],
  });

  return (
    <Card className="bg-dark-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-white">Telegram Bot</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-success-500 rounded-full"></div>
            <span className="text-xs text-gray-400">
              {isLoading ? "..." : telegramStatus?.isInitialized ? "Online" : "Offline"}
            </span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Bot Username</span>
              <span className="text-white font-mono" data-testid="text-telegram-username">
                {telegramStatus?.username || "@gridbot_sol"}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Active Chats</span>
              <span className="text-white" data-testid="text-telegram-chats">
                {telegramStatus?.activeChats || 0}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Commands Today</span>
              <span className="text-white" data-testid="text-telegram-commands">
                {telegramStatus?.commandsToday || 0}
              </span>
            </div>
          </div>
        )}
        
        <div className="mt-4 p-3 bg-gray-700 rounded-lg">
          <p className="text-xs text-gray-300 mb-2">Recent Commands</p>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-400">/status SOL</span>
              <span className="text-gray-500">2m ago</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">/pause RAY</span>
              <span className="text-gray-500">15m ago</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">/pnl</span>
              <span className="text-gray-500">1h ago</span>
            </div>
          </div>
        </div>
        
        <Button 
          className="w-full mt-4 bg-gray-700 hover:bg-gray-600 text-white"
          data-testid="button-manage-telegram-settings"
        >
          <MessageCircle className="w-4 h-4 mr-2" />
          Manage Bot Settings
        </Button>
      </CardContent>
    </Card>
  );
}
