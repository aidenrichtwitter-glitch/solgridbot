import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { BarChart3, Grid3X3, History, MessageCircle, Wallet, Settings, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

const navigation = [
  { name: "Dashboard", href: "/", icon: Grid3X3 },
  { name: "Strategies", href: "/strategies", icon: BarChart3 },
  { name: "History", href: "/history", icon: History },
  { name: "Telegram Bot", href: "/telegram", icon: MessageCircle },
];

export default function Sidebar() {
  const [location] = useLocation();
  
  const { data: wallets } = useQuery({
    queryKey: ["/api/wallets"],
  });

  const activeWallet = wallets?.[0]; // Use first wallet for demo

  return (
    <div className="fixed left-0 top-0 h-full w-64 bg-dark-800 border-r border-gray-700 z-10">
      <div className="p-6">
        {/* Logo */}
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 bg-primary-600 rounded-lg flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">GridBot Pro</h1>
            <p className="text-xs text-gray-400">Solana Grid Trading</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            
            return (
              <Link key={item.name} href={item.href}>
                <a
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2 rounded-lg font-medium transition-colors",
                    isActive
                      ? "bg-primary-600 text-white"
                      : "text-gray-300 hover:text-white hover:bg-gray-700"
                  )}
                  data-testid={`nav-link-${item.name.toLowerCase().replace(' ', '-')}`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.name}</span>
                </a>
              </Link>
            );
          })}
        </nav>

        {/* Wallet Connection */}
        <div className="mt-8 p-4 bg-gray-700 rounded-lg">
          <div className="flex items-center space-x-3 mb-3">
            <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
              <Wallet className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-white">Phantom Wallet</p>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-success-500 rounded-full"></div>
                <p className="text-xs text-gray-400">Connected</p>
              </div>
            </div>
          </div>
          {activeWallet && (
            <>
              <p className="text-xs text-gray-400 font-mono" data-testid="text-wallet-address">
                {activeWallet.address.slice(0, 4)}...{activeWallet.address.slice(-4)}
              </p>
              <p className="text-sm font-semibold text-white mt-2" data-testid="text-wallet-balance">
                {activeWallet.balance} SOL
              </p>
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div className="mt-6 space-y-2">
          <Button 
            className="w-full bg-primary-600 hover:bg-primary-700 text-white"
            data-testid="button-new-strategy"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Strategy
          </Button>
          <Button 
            variant="outline"
            className="w-full bg-gray-700 hover:bg-gray-600 text-gray-300 border-gray-600"
            data-testid="button-settings"
          >
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>
      </div>
    </div>
  );
}
