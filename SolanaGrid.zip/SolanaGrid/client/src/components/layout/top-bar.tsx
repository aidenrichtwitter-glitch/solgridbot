import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

interface TopBarProps {
  title: string;
  subtitle: string;
}

export default function TopBar({ title, subtitle }: TopBarProps) {
  const { data: telegramStatus } = useQuery({
    queryKey: ["/api/telegram/status"],
  });

  return (
    <header className="bg-dark-800 border-b border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white" data-testid="text-page-title">{title}</h2>
          <p className="text-sm text-gray-400" data-testid="text-page-subtitle">{subtitle}</p>
        </div>
        <div className="flex items-center space-x-4">
          {/* RPC Status */}
          <div className="flex items-center space-x-2 px-3 py-1 bg-gray-700 rounded-full" data-testid="rpc-status">
            <div className="w-2 h-2 bg-success-500 rounded-full"></div>
            <span className="text-xs text-gray-300">QuickNode RPC</span>
          </div>
          
          {/* Telegram Status */}
          {telegramStatus?.isInitialized && (
            <div className="flex items-center space-x-2 px-3 py-1 bg-gray-700 rounded-full" data-testid="telegram-status">
              <div className="w-2 h-2 bg-success-500 rounded-full"></div>
              <span className="text-xs text-gray-300">Telegram Bot</span>
            </div>
          )}
          
          {/* Notifications */}
          <Button variant="ghost" size="sm" className="relative text-gray-400 hover:text-white" data-testid="button-notifications">
            <Bell className="w-5 h-5" />
            <Badge className="absolute -top-1 -right-1 w-4 h-4 bg-danger-500 text-xs text-white rounded-full flex items-center justify-center">
              3
            </Badge>
          </Button>
        </div>
      </div>
    </header>
  );
}
