import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { solanaService } from "./services/solana";
import { jupiterService } from "./services/jupiter";
import { gridBotService } from "./services/gridBot";
import { telegramService } from "./services/telegram";
import { insertStrategySchema, insertWalletSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Wallet routes
  app.get("/api/wallets", async (req, res) => {
    try {
      // For demo, return mock wallet - in production, get from user session
      const mockUserId = "user-1";
      const wallets = await storage.getWalletsByUserId(mockUserId);
      res.json(wallets);
    } catch (error) {
      res.status(500).json({ error: "Failed to get wallets" });
    }
  });

  app.post("/api/wallets", async (req, res) => {
    try {
      const validatedData = insertWalletSchema.parse(req.body);
      const wallet = await storage.createWallet(validatedData);
      res.json(wallet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid wallet data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create wallet" });
      }
    }
  });

  app.get("/api/wallets/:id/balance", async (req, res) => {
    try {
      const { id } = req.params;
      const wallet = await storage.getWallet(id);
      
      if (!wallet) {
        return res.status(404).json({ error: "Wallet not found" });
      }

      const balance = await solanaService.getWalletBalance(wallet.address);
      await storage.updateWalletBalance(id, balance.toString());
      
      res.json({ balance });
    } catch (error) {
      res.status(500).json({ error: "Failed to get wallet balance" });
    }
  });

  // Strategy routes
  app.get("/api/strategies", async (req, res) => {
    try {
      // For demo, return mock user strategies
      const mockUserId = "user-1";
      const strategies = await storage.getStrategiesByUserId(mockUserId);
      res.json(strategies);
    } catch (error) {
      res.status(500).json({ error: "Failed to get strategies" });
    }
  });

  app.post("/api/strategies", async (req, res) => {
    try {
      const validatedData = insertStrategySchema.parse(req.body);
      const strategy = await storage.createStrategy(validatedData);
      
      // Start the grid bot for this strategy
      await gridBotService.createGridStrategy(strategy);
      
      res.json(strategy);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid strategy data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create strategy" });
      }
    }
  });

  app.get("/api/strategies/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const strategy = await storage.getStrategy(id);
      
      if (!strategy) {
        return res.status(404).json({ error: "Strategy not found" });
      }

      const stats = await gridBotService.getStrategyStats(id);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to get strategy" });
    }
  });

  app.patch("/api/strategies/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (status === 'paused') {
        await gridBotService.pauseStrategy(id);
      } else if (status === 'active') {
        await gridBotService.resumeStrategy(id);
      } else if (status === 'stopped') {
        await gridBotService.stopStrategy(id);
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update strategy" });
    }
  });

  app.delete("/api/strategies/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await gridBotService.stopStrategy(id);
      await storage.deleteStrategy(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete strategy" });
    }
  });

  // Trade routes
  app.get("/api/trades", async (req, res) => {
    try {
      const { strategyId } = req.query;
      
      let trades;
      if (strategyId) {
        trades = await storage.getTradesByStrategyId(strategyId as string);
      } else {
        // For demo, get all trades for mock user
        const mockUserId = "user-1";
        trades = await storage.getTradesByUserId(mockUserId);
      }
      
      res.json(trades);
    } catch (error) {
      res.status(500).json({ error: "Failed to get trades" });
    }
  });

  // Jupiter API routes
  app.get("/api/tokens/search", async (req, res) => {
    try {
      const { q } = req.query;
      const tokens = await jupiterService.searchTokens(q as string);
      res.json(tokens);
    } catch (error) {
      res.status(500).json({ error: "Failed to search tokens" });
    }
  });

  app.get("/api/tokens/price/:mint", async (req, res) => {
    try {
      const { mint } = req.params;
      const price = await jupiterService.getTokenPrice(mint);
      res.json({ price });
    } catch (error) {
      res.status(500).json({ error: "Failed to get token price" });
    }
  });

  app.post("/api/quotes", async (req, res) => {
    try {
      const { inputMint, outputMint, amount, slippageBps } = req.body;
      const quote = await jupiterService.getQuote(inputMint, outputMint, amount, slippageBps);
      res.json(quote);
    } catch (error) {
      res.status(500).json({ error: "Failed to get quote" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      // For demo, return mock stats - in production, calculate from real data
      const mockUserId = "user-1";
      const strategies = await storage.getStrategiesByUserId(mockUserId);
      const trades = await storage.getTradesByUserId(mockUserId);
      
      const totalPnL = strategies.reduce((sum, s) => sum + parseFloat(s.totalPnL), 0);
      const activeStrategies = strategies.filter(s => s.status === 'active').length;
      const volume24h = trades.reduce((sum, t) => sum + (parseFloat(t.amount) * parseFloat(t.price)), 0);
      
      res.json({
        totalPnL: totalPnL.toFixed(2),
        activeStrategies,
        volume24h: volume24h.toFixed(2),
        portfolioValue: "25630.89", // Mock value
        profitableStrategies: strategies.filter(s => parseFloat(s.totalPnL) > 0).length,
        totalTrades: trades.length,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get dashboard stats" });
    }
  });

  // Telegram routes
  app.get("/api/telegram/status", async (req, res) => {
    try {
      res.json({
        isInitialized: telegramService.isInitialized(),
        username: "@gridbot_sol",
        activeChats: 3,
        commandsToday: 47,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get Telegram status" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
