import { Connection, PublicKey, Keypair, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { getAssociatedTokenAddress, getAccount } from '@solana/spl-token';

export class SolanaService {
  private connection: Connection;
  private rpcUrl: string;

  constructor() {
    this.rpcUrl = process.env.QUICKNODE_RPC_URL || process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
    this.connection = new Connection(this.rpcUrl, 'confirmed');
  }

  async getConnection(): Promise<Connection> {
    return this.connection;
  }

  async getWalletBalance(publicKey: string): Promise<number> {
    try {
      const pubKey = new PublicKey(publicKey);
      const balance = await this.connection.getBalance(pubKey);
      return balance / LAMPORTS_PER_SOL;
    } catch (error) {
      console.error('Error getting wallet balance:', error);
      throw new Error('Failed to get wallet balance');
    }
  }

  async getTokenBalance(walletAddress: string, tokenMint: string): Promise<number> {
    try {
      const walletPublicKey = new PublicKey(walletAddress);
      const tokenMintPublicKey = new PublicKey(tokenMint);
      
      const associatedTokenAddress = await getAssociatedTokenAddress(
        tokenMintPublicKey,
        walletPublicKey
      );

      const tokenAccount = await getAccount(this.connection, associatedTokenAddress);
      return Number(tokenAccount.amount) / Math.pow(10, 6); // Assuming 6 decimals for most tokens
    } catch (error) {
      console.error('Error getting token balance:', error);
      return 0;
    }
  }

  createWalletFromPrivateKey(privateKey: string): Keypair {
    try {
      const secretKey = new Uint8Array(JSON.parse(privateKey));
      return Keypair.fromSecretKey(secretKey);
    } catch (error) {
      console.error('Error creating wallet from private key:', error);
      throw new Error('Invalid private key format');
    }
  }

  async isValidAddress(address: string): Promise<boolean> {
    try {
      new PublicKey(address);
      return true;
    } catch {
      return false;
    }
  }

  async getRecentBlockhash(): Promise<string> {
    try {
      const { blockhash } = await this.connection.getLatestBlockhash();
      return blockhash;
    } catch (error) {
      console.error('Error getting recent blockhash:', error);
      throw new Error('Failed to get recent blockhash');
    }
  }
}

export const solanaService = new SolanaService();
