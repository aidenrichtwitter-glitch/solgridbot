import TelegramBot from 'node-telegram-bot-api';
import { storage } from '../storage';

export class TelegramService {
  private bot: TelegramBot | null = null;
  private botToken: string;

  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN || '';
    if (this.botToken) {
      this.initializeBot();
    }
  }

  private initializeBot() {
    try {
      this.bot = new TelegramBot(this.botToken, { polling: true });
      this.setupCommandHandlers();
      console.log('Telegram bot initialized successfully');
    } catch (error) {
      console.error('Failed to initialize Telegram bot:', error);
    }
  }

  private setupCommandHandlers() {
    if (!this.bot) return;

    // Start command
    this.bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      await this.sendMessage(chatId, 
        '🤖 Welcome to GridBot Pro!\n\n' +
        'Available commands:\n' +
        '/status - Get strategy status\n' +
        '/pnl - View profit/loss\n' +
        '/strategies - List all strategies\n' +
        '/pause <strategy_id> - Pause a strategy\n' +
        '/resume <strategy_id> - Resume a strategy\n' +
        '/help - Show this help message'
      );
    });

    // Help command
    this.bot.onText(/\/help/, async (msg) => {
      const chatId = msg.chat.id;
      await this.sendMessage(chatId,
        '📖 GridBot Pro Commands:\n\n' +
        '🔍 /status - Get overall status\n' +
        '💰 /pnl - View profit/loss summary\n' +
        '📊 /strategies - List all strategies\n' +
        '⏸️ /pause <id> - Pause strategy\n' +
        '▶️ /resume <id> - Resume strategy\n' +
        '📈 /price <token> - Get token price\n' +
        '❓ /help - Show this message'
      );
    });

    // Status command
    this.bot.onText(/\/status/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        // Mock response - in production, get real data from storage
        await this.sendMessage(chatId,
          '📊 *GridBot Status*\n\n' +
          '🟢 Active Strategies: 7\n' +
          '💰 Total P&L: +$2,847.32\n' +
          '📈 24h Volume: $18,492\n' +
          '💼 Portfolio: $25,630.89\n\n' +
          '🔄 All systems operational',
          { parse_mode: 'Markdown' }
        );
      } catch (error) {
        await this.sendMessage(chatId, '❌ Failed to get status');
      }
    });

    // P&L command
    this.bot.onText(/\/pnl/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        await this.sendMessage(chatId,
          '💰 *Profit & Loss Summary*\n\n' +
          '📊 Total P&L: +$2,847.32 (+12.8%)\n' +
          '📈 Today: +$284.50\n' +
          '📅 This Week: +$1,245.80\n' +
          '📆 This Month: +$2,847.32\n\n' +
          '🏆 Best Strategy: SOL/USDC (+$584.20)\n' +
          '📉 Worst Strategy: RAY/USDC (-$42.10)',
          { parse_mode: 'Markdown' }
        );
      } catch (error) {
        await this.sendMessage(chatId, '❌ Failed to get P&L data');
      }
    });

    // Strategies command
    this.bot.onText(/\/strategies/, async (msg) => {
      const chatId = msg.chat.id;
      try {
        await this.sendMessage(chatId,
          '📊 *Active Strategies*\n\n' +
          '🟢 SOL/USDC - Active\n' +
          '   Price: $98.45 | P&L: +$284.50\n\n' +
          '🟡 RAY/USDC - Paused\n' +
          '   Price: $2.84 | P&L: -$42.10\n\n' +
          '🟢 ORCA/USDC - Active\n' +
          '   Price: $3.21 | P&L: +$156.80\n\n' +
          'Use /pause <id> or /resume <id> to control',
          { parse_mode: 'Markdown' }
        );
      } catch (error) {
        await this.sendMessage(chatId, '❌ Failed to get strategies');
      }
    });

    // Pause command
    this.bot.onText(/\/pause (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const strategyId = match?.[1];
      
      if (!strategyId) {
        await this.sendMessage(chatId, '❌ Please provide a strategy ID');
        return;
      }

      try {
        // In production, implement actual pause logic
        await this.sendMessage(chatId, `⏸️ Strategy ${strategyId} has been paused`);
      } catch (error) {
        await this.sendMessage(chatId, '❌ Failed to pause strategy');
      }
    });

    // Resume command
    this.bot.onText(/\/resume (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const strategyId = match?.[1];
      
      if (!strategyId) {
        await this.sendMessage(chatId, '❌ Please provide a strategy ID');
        return;
      }

      try {
        // In production, implement actual resume logic
        await this.sendMessage(chatId, `▶️ Strategy ${strategyId} has been resumed`);
      } catch (error) {
        await this.sendMessage(chatId, '❌ Failed to resume strategy');
      }
    });

    // Price command
    this.bot.onText(/\/price (.+)/, async (msg, match) => {
      const chatId = msg.chat.id;
      const token = match?.[1]?.toUpperCase();
      
      if (!token) {
        await this.sendMessage(chatId, '❌ Please provide a token symbol');
        return;
      }

      try {
        // Mock price response - in production, get from Jupiter API
        const prices: { [key: string]: string } = {
          'SOL': '$98.45',
          'RAY': '$2.84',
          'ORCA': '$3.21',
          'USDC': '$1.00',
        };

        const price = prices[token] || 'Price not available';
        await this.sendMessage(chatId, `💰 ${token} Price: ${price}`);
      } catch (error) {
        await this.sendMessage(chatId, '❌ Failed to get price');
      }
    });
  }

  async sendMessage(chatId: number, text: string, options?: any): Promise<void> {
    if (!this.bot) {
      console.error('Telegram bot not initialized');
      return;
    }

    try {
      await this.bot.sendMessage(chatId, text, options);
    } catch (error) {
      console.error('Failed to send Telegram message:', error);
    }
  }

  async sendTradeNotification(chatId: number, trade: any): Promise<void> {
    const emoji = trade.side === 'buy' ? '🟢' : '🔴';
    const message = 
      `${emoji} *Trade Executed*\n\n` +
      `Action: ${trade.side.toUpperCase()}\n` +
      `Token: ${trade.tokenPair}\n` +
      `Amount: ${trade.amount}\n` +
      `Price: $${trade.price}\n` +
      `P&L: ${trade.pnl >= 0 ? '+' : ''}$${trade.pnl}`;

    await this.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  }

  async sendStrategyAlert(chatId: number, strategy: any, alertType: string): Promise<void> {
    let message = `🚨 *Strategy Alert*\n\n`;
    
    switch (alertType) {
      case 'profit_target':
        message += `🎯 Profit target reached!\n`;
        break;
      case 'stop_loss':
        message += `🛑 Stop loss triggered!\n`;
        break;
      case 'grid_complete':
        message += `✅ Grid completed!\n`;
        break;
      default:
        message += `ℹ️ Strategy update\n`;
    }

    message += 
      `Strategy: ${strategy.tokenPair}\n` +
      `Current P&L: ${strategy.totalPnL >= 0 ? '+' : ''}$${strategy.totalPnL}`;

    await this.sendMessage(chatId, message, { parse_mode: 'Markdown' });
  }

  isInitialized(): boolean {
    return this.bot !== null;
  }
}

export const telegramService = new TelegramService();
