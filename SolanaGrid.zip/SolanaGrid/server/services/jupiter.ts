import fetch from 'node-fetch';

interface JupiterQuoteResponse {
  data: {
    inputMint: string;
    inAmount: string;
    outputMint: string;
    outAmount: string;
    otherAmountThreshold: string;
    swapMode: string;
    slippageBps: number;
    platformFee: any;
    priceImpactPct: string;
    routePlan: any[];
  }[];
  timeTaken: number;
}

interface JupiterSwapResponse {
  swapTransaction: string;
}

interface TokenInfo {
  address: string;
  chainId: number;
  decimals: number;
  name: string;
  symbol: string;
  logoURI?: string;
  tags?: string[];
}

export class JupiterService {
  private baseUrl = 'https://quote-api.jup.ag/v6';
  private priceApiUrl = 'https://price.jup.ag/v4';

  async getQuote(
    inputMint: string,
    outputMint: string,
    amount: number,
    slippageBps = 50
  ): Promise<JupiterQuoteResponse> {
    try {
      const url = `${this.baseUrl}/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount}&slippageBps=${slippageBps}`;
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Jupiter API error: ${response.statusText}`);
      }

      return await response.json() as JupiterQuoteResponse;
    } catch (error) {
      console.error('Error getting Jupiter quote:', error);
      throw new Error('Failed to get quote from Jupiter');
    }
  }

  async getSwapTransaction(
    quoteResponse: JupiterQuoteResponse,
    userPublicKey: string
  ): Promise<JupiterSwapResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/swap`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          quoteResponse: quoteResponse.data[0],
          userPublicKey,
          wrapAndUnwrapSol: true,
        }),
      });

      if (!response.ok) {
        throw new Error(`Jupiter swap API error: ${response.statusText}`);
      }

      return await response.json() as JupiterSwapResponse;
    } catch (error) {
      console.error('Error getting swap transaction:', error);
      throw new Error('Failed to get swap transaction from Jupiter');
    }
  }

  async getTokenPrice(tokenMint: string): Promise<number> {
    try {
      const response = await fetch(`${this.priceApiUrl}/price?ids=${tokenMint}`);
      if (!response.ok) {
        throw new Error(`Jupiter price API error: ${response.statusText}`);
      }

      const data = await response.json() as { data: { [key: string]: { price: number } } };
      return data.data[tokenMint]?.price || 0;
    } catch (error) {
      console.error('Error getting token price:', error);
      throw new Error('Failed to get token price');
    }
  }

  async getTokenList(): Promise<TokenInfo[]> {
    try {
      const response = await fetch('https://token.jup.ag/all');
      if (!response.ok) {
        throw new Error(`Jupiter token list API error: ${response.statusText}`);
      }

      return await response.json() as TokenInfo[];
    } catch (error) {
      console.error('Error getting token list:', error);
      throw new Error('Failed to get token list');
    }
  }

  async searchTokens(query: string): Promise<TokenInfo[]> {
    try {
      const tokenList = await this.getTokenList();
      const searchTerm = query.toLowerCase();
      
      return tokenList.filter(token => 
        token.symbol.toLowerCase().includes(searchTerm) ||
        token.name.toLowerCase().includes(searchTerm) ||
        token.address.toLowerCase().includes(searchTerm)
      ).slice(0, 20); // Limit to 20 results
    } catch (error) {
      console.error('Error searching tokens:', error);
      return [];
    }
  }

  // Common token mints for quick access
  getCommonTokens() {
    return {
      SOL: 'So11111111111111111111111111111111111111112',
      USDC: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
      USDT: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
      RAY: '4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R',
      ORCA: 'orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE',
      SRM: 'SRMuApVNdxXokk5GT7XD5cUUgXMBCoAz2LHeuAoKWRt',
      FTT: 'AGFEad2et2ZJif9jaGpdMixQqvW5i81aBdvKe7PHNfz3',
    };
  }
}

export const jupiterService = new JupiterService();
