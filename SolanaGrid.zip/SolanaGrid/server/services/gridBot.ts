import { jupiterService } from './jupiter';
import { solanaService } from './solana';
import { storage } from '../storage';
import { Strategy, Trade } from '@shared/schema';

interface GridLevel {
  price: number;
  amount: number;
  side: 'buy' | 'sell';
  filled: boolean;
}

export class GridBotService {
  private activeStrategies: Map<string, NodeJS.Timer> = new Map();

  async createGridStrategy(strategy: Strategy): Promise<void> {
    try {
      // Calculate grid levels
      const gridLevels = this.calculateGridLevels(strategy);
      
      // Place initial orders
      await this.placeInitialOrders(strategy, gridLevels);
      
      // Start monitoring
      this.startStrategyMonitoring(strategy.id);
      
      console.log(`Grid strategy ${strategy.id} created and started`);
    } catch (error) {
      console.error('Error creating grid strategy:', error);
      throw error;
    }
  }

  private calculateGridLevels(strategy: Strategy): GridLevel[] {
    const levels: GridLevel[] = [];
    const lowerPrice = parseFloat(strategy.lowerPrice);
    const upperPrice = parseFloat(strategy.upperPrice);
    const gridCount = strategy.gridLevels;
    const totalInvestment = parseFloat(strategy.totalInvestment);
    
    const priceStep = (upperPrice - lowerPrice) / (gridCount - 1);
    const amountPerLevel = totalInvestment / gridCount;

    for (let i = 0; i < gridCount; i++) {
      const price = lowerPrice + (i * priceStep);
      
      levels.push({
        price,
        amount: amountPerLevel / price, // Amount in base token
        side: i < gridCount / 2 ? 'buy' : 'sell',
        filled: false,
      });
    }

    return levels;
  }

  private async placeInitialOrders(strategy: Strategy, gridLevels: GridLevel[]): Promise<void> {
    const currentPrice = await jupiterService.getTokenPrice(strategy.baseToken);
    
    // Place buy orders below current price and sell orders above
    for (const level of gridLevels) {
      if (level.side === 'buy' && level.price < currentPrice) {
        await this.placeBuyOrder(strategy, level);
      } else if (level.side === 'sell' && level.price > currentPrice) {
        await this.placeSellOrder(strategy, level);
      }
    }
  }

  private async placeBuyOrder(strategy: Strategy, level: GridLevel): Promise<void> {
    try {
      // Get quote for buying base token with quote token
      const amountInQuote = level.amount * level.price;
      const quote = await jupiterService.getQuote(
        strategy.quoteToken,
        strategy.baseToken,
        Math.floor(amountInQuote * 1e6), // Convert to smallest unit
        50 // 0.5% slippage
      );

      // In a real implementation, you would:
      // 1. Get the swap transaction from Jupiter
      // 2. Sign and send the transaction
      // 3. Monitor for confirmation
      // 4. Update the trade record

      // For now, we'll create a pending trade record
      await storage.createTrade({
        strategyId: strategy.id,
        txSignature: `pending_${Date.now()}_${Math.random()}`,
        side: 'buy',
        amount: level.amount.toString(),
        price: level.price.toString(),
        pnl: "0",
      });

      // Update strategy stats
      await storage.updateStrategy(strategy.id, {
        ordersPlaced: (strategy.ordersPlaced || 0) + 1,
      });

      console.log(`Buy order placed for ${strategy.tokenPair} at $${level.price}`);
    } catch (error) {
      console.error('Error placing buy order:', error);
    }
  }

  private async placeSellOrder(strategy: Strategy, level: GridLevel): Promise<void> {
    try {
      // Get quote for selling base token for quote token
      const quote = await jupiterService.getQuote(
        strategy.baseToken,
        strategy.quoteToken,
        Math.floor(level.amount * 1e9), // Convert to smallest unit
        50 // 0.5% slippage
      );

      // Create pending trade record
      await storage.createTrade({
        strategyId: strategy.id,
        txSignature: `pending_${Date.now()}_${Math.random()}`,
        side: 'sell',
        amount: level.amount.toString(),
        price: level.price.toString(),
        pnl: "0",
      });

      // Update strategy stats
      await storage.updateStrategy(strategy.id, {
        ordersPlaced: (strategy.ordersPlaced || 0) + 1,
      });

      console.log(`Sell order placed for ${strategy.tokenPair} at $${level.price}`);
    } catch (error) {
      console.error('Error placing sell order:', error);
    }
  }

  private startStrategyMonitoring(strategyId: string): void {
    // Monitor strategy every 30 seconds
    const interval = setInterval(async () => {
      try {
        await this.monitorStrategy(strategyId);
      } catch (error) {
        console.error(`Error monitoring strategy ${strategyId}:`, error);
      }
    }, 30000);

    this.activeStrategies.set(strategyId, interval);
  }

  private async monitorStrategy(strategyId: string): Promise<void> {
    const strategy = await storage.getStrategy(strategyId);
    if (!strategy || strategy.status !== 'active') {
      this.stopStrategyMonitoring(strategyId);
      return;
    }

    // Get current price
    const currentPrice = await jupiterService.getTokenPrice(strategy.baseToken);
    
    // Update strategy with current price
    await storage.updateStrategy(strategyId, {
      currentPrice: currentPrice.toString(),
    });

    // Check for filled orders and place new ones
    await this.checkAndRefillOrders(strategy, currentPrice);

    // Calculate and update P&L
    await this.updateStrategyPnL(strategy);
  }

  private async checkAndRefillOrders(strategy: Strategy, currentPrice: number): Promise<void> {
    // In a real implementation, you would:
    // 1. Check blockchain for filled orders
    // 2. Update trade records with actual fills
    // 3. Place new orders to maintain the grid
    // 4. Send notifications for filled trades

    // For demo purposes, we'll simulate some order fills
    const trades = await storage.getTradesByStrategyId(strategy.id);
    const pendingTrades = trades.filter(t => t.status === 'pending');

    for (const trade of pendingTrades) {
      const tradePrice = parseFloat(trade.price);
      
      // Simulate order fill if price crosses the order price
      const shouldFill = (
        (trade.side === 'buy' && currentPrice <= tradePrice * 1.01) ||
        (trade.side === 'sell' && currentPrice >= tradePrice * 0.99)
      );

      if (shouldFill && Math.random() < 0.1) { // 10% chance per check
        await this.fillOrder(strategy, trade, currentPrice);
      }
    }
  }

  private async fillOrder(strategy: Strategy, trade: Trade, fillPrice: number): Promise<void> {
    // Update trade as filled
    await storage.updateTrade(trade.id, {
      status: 'confirmed',
      price: fillPrice.toString(),
    });

    // Update strategy stats
    await storage.updateStrategy(strategy.id, {
      ordersFilled: (strategy.ordersFilled || 0) + 1,
    });

    // Place opposite order (if buy filled, place sell above, if sell filled, place buy below)
    if (trade.side === 'buy') {
      // Place sell order above
      const sellPrice = fillPrice * 1.02; // 2% profit target
      await this.placeSellOrder(strategy, {
        price: sellPrice,
        amount: parseFloat(trade.amount),
        side: 'sell',
        filled: false,
      });
    } else {
      // Place buy order below
      const buyPrice = fillPrice * 0.98; // 2% below
      await this.placeBuyOrder(strategy, {
        price: buyPrice,
        amount: parseFloat(trade.amount),
        side: 'buy',
        filled: false,
      });
    }

    console.log(`Order filled: ${trade.side} ${trade.amount} ${strategy.tokenPair} at $${fillPrice}`);
  }

  private async updateStrategyPnL(strategy: Strategy): Promise<void> {
    const trades = await storage.getTradesByStrategyId(strategy.id);
    const filledTrades = trades.filter(t => t.status === 'confirmed');

    let totalPnL = 0;
    
    // Calculate realized P&L from completed buy-sell pairs
    for (const trade of filledTrades) {
      const pnl = parseFloat(trade.pnl);
      totalPnL += pnl;
    }

    await storage.updateStrategy(strategy.id, {
      totalPnL: totalPnL.toString(),
    });
  }

  async pauseStrategy(strategyId: string): Promise<void> {
    await storage.updateStrategy(strategyId, { status: 'paused' });
    this.stopStrategyMonitoring(strategyId);
    console.log(`Strategy ${strategyId} paused`);
  }

  async resumeStrategy(strategyId: string): Promise<void> {
    const strategy = await storage.getStrategy(strategyId);
    if (strategy) {
      await storage.updateStrategy(strategyId, { status: 'active' });
      this.startStrategyMonitoring(strategyId);
      console.log(`Strategy ${strategyId} resumed`);
    }
  }

  async stopStrategy(strategyId: string): Promise<void> {
    await storage.updateStrategy(strategyId, { status: 'stopped' });
    this.stopStrategyMonitoring(strategyId);
    console.log(`Strategy ${strategyId} stopped`);
  }

  private stopStrategyMonitoring(strategyId: string): void {
    const interval = this.activeStrategies.get(strategyId);
    if (interval) {
      clearInterval(interval);
      this.activeStrategies.delete(strategyId);
    }
  }

  async getStrategyStats(strategyId: string): Promise<any> {
    const strategy = await storage.getStrategy(strategyId);
    const trades = await storage.getTradesByStrategyId(strategyId);
    
    if (!strategy) {
      throw new Error('Strategy not found');
    }

    const filledTrades = trades.filter(t => t.status === 'confirmed');
    const pendingTrades = trades.filter(t => t.status === 'pending');

    return {
      strategy,
      totalTrades: trades.length,
      filledTrades: filledTrades.length,
      pendingTrades: pendingTrades.length,
      totalPnL: strategy.totalPnL,
      currentPrice: strategy.currentPrice,
    };
  }
}

export const gridBotService = new GridBotService();
