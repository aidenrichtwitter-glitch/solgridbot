import { type User, type InsertUser, type Wallet, type InsertWallet, type Strategy, type InsertStrategy, type Trade, type InsertTrade, type TelegramConfig, type InsertTelegramConfig } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Wallets
  getWallet(id: string): Promise<Wallet | undefined>;
  getWalletsByUserId(userId: string): Promise<Wallet[]>;
  createWallet(wallet: InsertWallet): Promise<Wallet>;
  updateWalletBalance(id: string, balance: string): Promise<void>;

  // Strategies
  getStrategy(id: string): Promise<Strategy | undefined>;
  getStrategiesByUserId(userId: string): Promise<Strategy[]>;
  createStrategy(strategy: InsertStrategy): Promise<Strategy>;
  updateStrategy(id: string, updates: Partial<Strategy>): Promise<void>;
  deleteStrategy(id: string): Promise<void>;

  // Trades
  getTrade(id: string): Promise<Trade | undefined>;
  getTradesByStrategyId(strategyId: string): Promise<Trade[]>;
  getTradesByUserId(userId: string): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: string, updates: Partial<Trade>): Promise<void>;

  // Telegram Config
  getTelegramConfig(userId: string): Promise<TelegramConfig | undefined>;
  createTelegramConfig(config: InsertTelegramConfig): Promise<TelegramConfig>;
  updateTelegramConfig(userId: string, updates: Partial<TelegramConfig>): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private wallets: Map<string, Wallet>;
  private strategies: Map<string, Strategy>;
  private trades: Map<string, Trade>;
  private telegramConfigs: Map<string, TelegramConfig>;

  constructor() {
    this.users = new Map();
    this.wallets = new Map();
    this.strategies = new Map();
    this.trades = new Map();
    this.telegramConfigs = new Map();
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Wallets
  async getWallet(id: string): Promise<Wallet | undefined> {
    return this.wallets.get(id);
  }

  async getWalletsByUserId(userId: string): Promise<Wallet[]> {
    return Array.from(this.wallets.values()).filter(
      (wallet) => wallet.userId === userId
    );
  }

  async createWallet(insertWallet: InsertWallet): Promise<Wallet> {
    const id = randomUUID();
    const wallet: Wallet = {
      ...insertWallet,
      id,
      balance: "0",
      isActive: true,
      createdAt: new Date(),
    };
    this.wallets.set(id, wallet);
    return wallet;
  }

  async updateWalletBalance(id: string, balance: string): Promise<void> {
    const wallet = this.wallets.get(id);
    if (wallet) {
      wallet.balance = balance;
      this.wallets.set(id, wallet);
    }
  }

  // Strategies
  async getStrategy(id: string): Promise<Strategy | undefined> {
    return this.strategies.get(id);
  }

  async getStrategiesByUserId(userId: string): Promise<Strategy[]> {
    return Array.from(this.strategies.values()).filter(
      (strategy) => strategy.userId === userId
    );
  }

  async createStrategy(insertStrategy: InsertStrategy): Promise<Strategy> {
    const id = randomUUID();
    const strategy: Strategy = {
      ...insertStrategy,
      id,
      status: "active",
      currentPrice: null,
      totalPnL: "0",
      ordersPlaced: 0,
      ordersFilled: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.strategies.set(id, strategy);
    return strategy;
  }

  async updateStrategy(id: string, updates: Partial<Strategy>): Promise<void> {
    const strategy = this.strategies.get(id);
    if (strategy) {
      const updatedStrategy = { ...strategy, ...updates, updatedAt: new Date() };
      this.strategies.set(id, updatedStrategy);
    }
  }

  async deleteStrategy(id: string): Promise<void> {
    this.strategies.delete(id);
  }

  // Trades
  async getTrade(id: string): Promise<Trade | undefined> {
    return this.trades.get(id);
  }

  async getTradesByStrategyId(strategyId: string): Promise<Trade[]> {
    return Array.from(this.trades.values()).filter(
      (trade) => trade.strategyId === strategyId
    );
  }

  async getTradesByUserId(userId: string): Promise<Trade[]> {
    const userStrategies = await this.getStrategiesByUserId(userId);
    const strategyIds = userStrategies.map((s) => s.id);
    return Array.from(this.trades.values()).filter(
      (trade) => strategyIds.includes(trade.strategyId)
    );
  }

  async createTrade(insertTrade: InsertTrade): Promise<Trade> {
    const id = randomUUID();
    const trade: Trade = {
      ...insertTrade,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.trades.set(id, trade);
    return trade;
  }

  async updateTrade(id: string, updates: Partial<Trade>): Promise<void> {
    const trade = this.trades.get(id);
    if (trade) {
      const updatedTrade = { ...trade, ...updates };
      this.trades.set(id, updatedTrade);
    }
  }

  // Telegram Config
  async getTelegramConfig(userId: string): Promise<TelegramConfig | undefined> {
    return Array.from(this.telegramConfigs.values()).find(
      (config) => config.userId === userId
    );
  }

  async createTelegramConfig(insertConfig: InsertTelegramConfig): Promise<TelegramConfig> {
    const id = randomUUID();
    const config: TelegramConfig = {
      ...insertConfig,
      id,
      isActive: true,
      createdAt: new Date(),
    };
    this.telegramConfigs.set(id, config);
    return config;
  }

  async updateTelegramConfig(userId: string, updates: Partial<TelegramConfig>): Promise<void> {
    const config = Array.from(this.telegramConfigs.values()).find(
      (c) => c.userId === userId
    );
    if (config) {
      const updatedConfig = { ...config, ...updates };
      this.telegramConfigs.set(config.id, updatedConfig);
    }
  }
}

export const storage = new MemStorage();
